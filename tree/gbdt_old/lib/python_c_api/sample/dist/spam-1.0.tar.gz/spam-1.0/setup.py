from distutils.core import setup, Extension

module = Extension('spam', sources = ['spammify.c'])

setup ( name = 'spam',
        version = '1.0',
        descripiton = 'spam system',
        ext_modules = [module])
