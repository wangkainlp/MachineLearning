#include "myutil.h"


int Matrix::in(int x, int y) {
    return this->at(x, y);
}
