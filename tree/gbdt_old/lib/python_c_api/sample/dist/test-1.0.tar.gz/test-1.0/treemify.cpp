#include <Python.h>
#include <stdlib.h>
#include "myutil.h"

static PyObject *TreeError;

static PyObject * tree_testdata(PyObject *self, PyObject *args) {
    PyObject * data_raw;
    int row_width;
    int col_width;
    if (!PyArg_ParseTuple(args, "Oii", &data_raw, &row_width, &col_width)) {
        return NULL;
    }

    Matrix data(data_raw, row_width, col_width);

    printf("%d\n", data.in(row_width - 1, col_width - 1));


    // return Py_BuildValue("i", 1);
    Py_RETURN_NONE;
}

static PyMethodDef TreeMethods[] = {
    // {"system", tree_system,   METH_VARARGS, "Execute a shell command."},
    {"testdata", tree_testdata, METH_VARARGS, "test pass array"},
    {NULL, NULL, 0, NULL}
};

PyMODINIT_FUNC inittree(void) {
    PyObject *m;

    m = Py_InitModule("tree", TreeMethods);

    if (m == NULL) {
        return;
    }


    TreeError = PyErr_NewException("tree.error", NULL, NULL);

    Py_INCREF(TreeError);

    PyModule_AddObject(m, "error", TreeError);

}



int main(int argc, char *argv[]) {
    // Pass argv[0] to the Python interpreter
    Py_SetProgramName(argv[0]);

    // Initialize the Python interpreter
    Py_Initialize();

    // Add a static module
    inittree();
}
